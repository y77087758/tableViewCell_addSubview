//
//  ViewController.m
//  tableViewCell的contentView cell addSubview和直接addSubview
//
//  Created by Yan on 16/4/28.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ViewController.h"

#define iPhoneWidth self.view.bounds.size.width
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
/** 表视图 */
@property (nonatomic,strong)UITableView *tableView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //设置表视图
    [self createTableView];
}

#pragma mark - 设置UI
-(void)createTableView{
    _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:(UITableViewStyleGrouped)];
    [self.view addSubview:_tableView];
    _tableView.dataSource = self;
    _tableView.delegate = self;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellID = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:cellID];
    }
    
    UILabel *label =[[UILabel alloc]initWithFrame:cell.bounds];
    label.backgroundColor = [UIColor redColor];
    label.text = [NSString stringWithFormat:@"第%ld行",indexPath.row];
    
    if (indexPath.section == 0) {
        [cell.contentView addSubview:label];
    }else{
        [cell addSubview:label];
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"cell.contentView添加子视图";
    }else{
        return @"cell添加子视图";
    }
}

#pragma mark - 触发事件
- (IBAction)click:(UIBarButtonItem*)sender {
    _tableView.editing = !_tableView.editing;
    if (_tableView.editing) {
        sender.title = @"编辑模式";
    }else{
        sender.title = @"普通模式";
    }
}

@end
