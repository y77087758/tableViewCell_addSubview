//
//  ViewController.h
//  tableViewCell的contentView cell addSubview和直接addSubview
//
//  Created by Yan on 16/4/28.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

